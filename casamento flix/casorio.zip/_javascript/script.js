$('.owl-carousel').owlCarousel({
  loop:false,
  margin:10,
  nav:true,
  responsive:{
      0:{
          items:1
      },
      600:{
          items:3
      },
      1000:{
          items:5
      }
  }
})

var fotoPrincipal = document.getElementById(`muda`)
function reset(){
    fotoPrincipal.innerHTML =``
}
function openFoto1(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min1.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto2(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min2.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto3(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min3.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto4(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min4.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto5(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min5.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto6(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min6.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto7(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min7.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto8(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min8.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto9(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min9.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto10(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min10.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto11(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min11.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto12(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min12.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto13(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min13.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto14(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min14.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}
function openFoto15(){
    fotoPrincipal.innerHTML = `<img class="box-filme" src="_imagens/min15.jpg"> <button role="button" class="botao" onclick="reset()"></i><i class="fas fa-times-circle"></i>FECHAR</button>`
}

